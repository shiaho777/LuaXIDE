export HOME=/home/luax
export TMPDIR=/tmp
export PATH=/bin:/usr/bin:/system/bin
export LUAX_NO_ROOT=1
